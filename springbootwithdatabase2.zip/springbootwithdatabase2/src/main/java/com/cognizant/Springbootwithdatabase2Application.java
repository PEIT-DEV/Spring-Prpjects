package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootwithdatabase2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootwithdatabase2Application.class, args);
	}

}
